
#ifndef WININDICATOR_H
#define WININDICATOR_H
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the KPORT_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// KPORT_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#include <windows.h>

#ifdef WININDICATOR_EXPORTS
#define WININDICATOR_API __declspec(dllexport)
#else
#define WININDICATOR_API __declspec(dllimport)
#endif


#ifdef __cplusplus
extern "C" {
#endif
//////////////////////////////////////////////////////////////////////

// Returns a value from specific ports.
__declspec(dllexport) SetIndicatorLamp(WORD bRed,WORD bYellow,WORD bGreen );
WININDICATOR_API VOID APIENTRY SetIndicatorBeep(DWORD dwTimes,DWORD dwDuration,DWORD dwInterval=200);

/////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif

#endif//end	 #ifndef KPORT_H
